import { readFile, mkdir, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const [html, css, js, core] = await Promise.all([
  readFile(resolve(root, 'app/index.html'), 'utf8'),
  readFile(resolve(root, 'app/styles.css'), 'utf8'),
  readFile(resolve(root, 'app/app.js'), 'utf8'),
  readFile(resolve(root, 'server/core.mjs'), 'utf8')
]);
await mkdir(resolve(root, 'dist/server'), { recursive: true });
await mkdir(resolve(root, 'dist/.openai'), { recursive: true });
const assetSource = `const assets = { html: ${JSON.stringify(html)}, css: ${JSON.stringify(css)}, js: ${JSON.stringify(js)} };\n`;
const workerEntry = `
const store = new MemoryStore(createDemoState());
let handler;
export default {
  fetch(request, env) {
    handler ||= createApp({ store, assets, env });
    return handler(request);
  }
};
`;
await Promise.all([
  writeFile(resolve(root, 'dist/index.html'), html),
  writeFile(resolve(root, 'dist/styles.css'), css),
  writeFile(resolve(root, 'dist/app.js'), js),
  writeFile(resolve(root, 'dist/server/index.js'), assetSource + core + workerEntry),
  writeFile(resolve(root, 'dist/.openai/hosting.json'), await readFile(resolve(root, '.openai/hosting.json')))
]);
console.log('Built TheatreOS Site Worker and browser assets');
